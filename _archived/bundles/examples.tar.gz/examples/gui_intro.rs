use eframe::{egui, epi};
use std::fs;

// Path to your logo image (relative to cargo run dir)
const LOGO_PATH: &str = "assets/smac_logo.png";

struct SmacIntroApp {
    logo_texture: Option<egui::TextureHandle>,
}

impl Default for SmacIntroApp {
    fn default() -> Self {
        Self { logo_texture: None }
    }
}

impl epi::App for SmacIntroApp {
    fn name(&self) -> &str {
        "Sid Meier's Alpha Centauri - Rust"
    }

    fn setup(
        &mut self,
        ctx: &egui::Context,
        _frame: &epi::Frame,
        _storage: Option<&dyn epi::Storage>,
    ) {
        if let Ok(img_bytes) = fs::read(LOGO_PATH) {
            if let Ok(image) = image::load_from_memory(&img_bytes) {
                let image_buffer = image.to_rgba8();
                let (w, h) = image_buffer.dimensions();
                let texture = ctx.load_texture(
                    "smac_logo",
                    egui::ColorImage::from_rgba_unmultiplied(
                        [w as usize, h as usize],
                        image_buffer.as_flat_samples().as_slice(),
                    ),
                    egui::TextureOptions::default(),
                );
                self.logo_texture = Some(texture);
            }
        }
    }

    fn update(&mut self, ctx: &egui::Context, _frame: &epi::Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.vertical_centered(|ui| {
                ui.add_space(30.0);
                ui.heading(egui::RichText::new("SID MEIER'S").size(32.0).color(egui::Color32::from_rgb(170, 170, 255)));
                ui.heading(egui::RichText::new("ALPHA CENTAURI").size(56.0).color(egui::Color32::from_rgb(100, 220, 255)));
                ui.add_space(20.0);
                if let Some(tex) = &self.logo_texture {
                    ui.image(tex, [350.0, 175.0]);
                }
                ui.add_space(40.0);
                ui.label(egui::RichText::new("A Rust Reimagining - Press ESC to quit").size(18.0));
            });
        });
    }
}

fn main() -> eframe::Result<()> {
    let native_options = eframe::NativeOptions::default();
    eframe::run_native(
        "Sid Meier's Alpha Centauri - Rust",
        native_options,
        Box::new(|_cc| Box::new(SmacIntroApp::default())),
    )
}
