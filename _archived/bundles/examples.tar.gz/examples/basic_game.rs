use smac_core::technology_tree::TechnologyTree;
use smac_core::units::{UnitPrototype, Unit};
use smac_core::map::Map;
use std::collections::HashSet;

fn main() {
    println!("=== SMAC Rust Technology Test ===");
    
    let tech_tree = TechnologyTree::new();
    let researched = HashSet::new();
    
    println!("\nStarting technologies:");
    for tech in tech_tree.get_available_technologies(&researched) {
        println!("  - {} ({})", tech.name, tech.id);
    }
    
    println!("\n=== SMAC Rust Unit Test ===");
    
    let scout = UnitPrototype::scout_patrol();
    let colony_pod = UnitPrototype::colony_pod();
    let former = UnitPrototype::former();
    
    println!("\nUnit Costs:");
    println!("  Scout Patrol: {} minerals", scout.cost);
    println!("  Colony Pod: {} minerals", colony_pod.cost);
    println!("  Former: {} minerals", former.cost);
    
    let unit = Unit::new(0, scout, (10, 10));
    println!("\nCreated {} at position {:?}", unit.design.name, unit.position);
    println!("  Movement: {} points", unit.moves_remaining);
    println!("  Attack: {}", unit.attack_strength());
    println!("  Defense: {}", unit.defense_strength());

    println!("\n=== SMAC Map Generation Test ===");
    let map = Map::generate(32, 16, 42);
    map.print_ascii();
}
