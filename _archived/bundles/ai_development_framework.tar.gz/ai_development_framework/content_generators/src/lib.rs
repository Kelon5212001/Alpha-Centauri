// Content generators placeholder
